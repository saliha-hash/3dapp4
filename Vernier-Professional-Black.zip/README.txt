Vernier Calliper — Professional Black Edition

Keep index.html, script.js, ui.js and verniercaliper.glb together. Publish the folder on GitHub Pages or another HTTPS static host. Three.js modules load from jsDelivr, so internet access is needed.

Main view: black background, instrument centered, minimal title. Tap Show controls & measurements to open controls.
