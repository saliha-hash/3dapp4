# Vernier Caliper — Precision Measurement Lab

This is an updated web version built around the supplied `verniercaliper.glb` model.

## Files
- `index.html` — responsive lab interface, style, controls, and lesson notes.
- `script.js` — 3D scene, model setup, jaw movement, object geometry/materials, and measurement math.
- `verniercaliper.glb` — the original 3D caliper model supplied for this project.

## Run locally
The page uses JavaScript modules and fetches the GLB, so open it through an HTTP server rather than double-clicking the file. From this folder, run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000` in a browser. Internet access is currently needed for the Three.js module imports from jsDelivr.

## Publish to GitHub Pages
Upload all three files (`index.html`, `script.js`, and `verniercaliper.glb`) into the same published folder in your repository. Keep their names unchanged, or update `MODEL_URL` in `script.js` if you rename the model.

## Measurement conventions
- Main-scale division: 1 mm.
- Vernier scale in calculation/inset: 20 divisions = 19 mm.
- Least count: 1.00 mm − 0.95 mm = 0.05 mm.
- Corrected reading: observed reading − zero error.
- Positive zero error is subtracted; negative zero error is added.

Important: 10 Vernier divisions = 9 mm implies a least count of 0.10 mm when one main division is 1 mm. That is inconsistent with 0.05 mm, so the calculation and inset use 20 divisions = 19 mm. The GLB's engraved scale is texture-based and has not been remodeled, so the educational inset is a clearly identified schematic; visual engraving and the simulated 0.05 mm calculation may not perfectly coincide.

## Object finish choices
Each object uses its own material settings: sphere (glossy), cube (semi-gloss), cylinder (polished metallic), cuboid (satin), cone (semi-gloss), slab (soft satin), and wire (polished metal).

## Notes
- The page retains the original model attribution and CC BY 4.0 license link supplied in the original project.
- The jaw/object travel is capped to 100 mm in the controls to keep object placement within the supplied model's dependable range, even though the drawn main-scale texture extends farther.
