VERNIER CALLIPER — FIX UPDATE

Files in this ZIP (upload all to the repository root, replacing the old ones):
- index.html
- script.js
- verniercaliper.glb (unchanged)
- README.md

What was fixed:
1. Object Dimensions: the section was empty until an object was chosen. It now always shows a hint, and the size fields appear once an object is selected.
2. Zero error: slider and typed box now share one range, -5.00 to +5.00 mm (set by ZERO_RANGE at the top of script.js) (snapped to the 0.05 mm least count). Press Apply Zero Error (or Enter). The Apply button is no longer solid blue.
3. Zero error is now shown on the 3D caliper by shifting the main-scale graduations against the vernier zero, so the jaws always stay exactly on the object. Negative values with closed jaws are written as e.g. -1 mm + 14 x 0.05 = -0.30 mm.
4. Removing an object now closes the jaws automatically (smooth slide). To keep the jaws open instead, set CLOSE_JAWS_ON_REMOVE = false at the top of script.js.
5. Removed the black line along the top of the main scale (and the matching dark line along its bottom edge), the second row of tick marks, and the dark inch-scale bar ("1/128 in") above the main scale. The sliding part's upper housing keeps a plain steel colour.
6. Caliper turning black after leaving the page and coming back: the steel reflection map is lost when the browser frees graphics memory. It is now rebuilt automatically when the page returns (and after a WebGL context loss).
7. The jaw slider label now says 100 mm (the real limit) instead of 150 mm.

UPDATE 2 — vernier alignment and one even steel look:
8. The vernier scale is drawn by the program (not the photo). It uses the long vernier of the photographed caliper: 20 divisions of 1.95 mm (39 mm in total), labelled 0 to 10, least count 0.05 mm. Its zero line is at exactly the same position as the main-scale 0, so with the jaws closed and zero error 0.00 mm the two zeros coincide. The line weights match the main scale so coinciding lines read as one line.
9. One colour everywhere: the main scale, vernier, jaws, body, screw bar, thumb roller and the sliding part's upper housing and blade all use exactly the same steel material (same colour, shine and reflections). The photographed parts are recoloured to the main scale's steel colour; only their light and dark detail (brushing, screws, knurling) is kept.
10. A thin white line under the vernier scale (from the photo) was removed.
11. Zero error range: slider, its labels and the typed box all use -5.00 to +5.00 mm (ZERO_RANGE at the top of script.js).
12. Black screen after some time: phones free the graphics memory when the page is in the background, the screen locks, or the caliper is scrolled out of view for a while. The 3D view now (a) rebuilds the steel reflections when the page returns or the caliper is scrolled back into view, (b) re-creates everything if the browser reports lost graphics, (c) has a watchdog that rebuilds the picture if it stays completely black for a few seconds, and (d) as a last resort reloads the page once if the graphics are not given back within 4 seconds.
13. Zero error section re-tested: slider, typed box, limits (-5 to +5 mm), snapping to 0.05 mm, Apply and Reset all stay in sync.
Tuning knobs at the top of script.js: STEEL_BASE (steel colour of the photo parts), STEEL_GAMMA, VERNIER_SPACING_MM, ZERO_RANGE.
